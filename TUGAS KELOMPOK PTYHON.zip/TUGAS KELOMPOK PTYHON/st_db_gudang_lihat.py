import streamlit as st
import st_db_gudang_koneksi
import mysql.connector
from sqlite3 import connect


def lihat():
    conn = st_db_gudang_koneksi.koneksi()#koneksi db
    mycursor = conn.cursor()
    mycursor.execute('select * from barang1')
    dataku = mycursor.fetchall()  #ambil data


#-------looping-------#
    nomer = 0
    total = 0
    st.warning ('LAPORAN DATA BARANG')
    st.write ('No - kode - Nama barang - satuan -stok')
    st.write('=======================================')

    for dt in dataku:
        nomer = nomer+1
        xkd  = dt[0]
        xnm  = dt[1]
        xunit = dt[2]
        xstok = dt[3]
        total   = total+xstok
        st.write(f'{nomer}.{xkd},{xnm},{xunit},{xstok}')
       
    st.success(f'Total stok={total}')
    st.balloons()
    conn.close() #tutup field koneksi

