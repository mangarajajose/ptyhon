import streamlit as st
import mysql.connector
import st_db_gudang_koneksi



def tambah_stok():
    st.info('TAMBAH DATA STOK MASUK')
    kode_barang = st.text_input('KODE BARANG')
    stok = st.text_input ('STOK')



    #tombol
    cek = st.button('SAVE')




    if(cek):
        if(kode_barang==''):
            st.error('KODE BARANG SALAH')
        else:
            #buka koneksi
            connect = st_db_gudang_koneksi.koneksi()
            sql = "select * from barang_masuk where kode_barang= '%s'" % kode_barang
            mycursor = connect.cursor() #siapkan data
            mycursor.execute(sql) #jalankan sql
            dataku = mycursor.fetchall()  #ambil data

            ada = len(dataku)           #ambil banyak data
            if(ada==''):
                st.error('stok Berlebih')
            else:
                #save data
                sql = "insert into barang_masuk \
                    (stok) value (%s)"
                dt = (stok)
                mycursor = connect.cursor()
                mycursor.execute(sql, dt)   #jalankan sql
                connect.commit()              #save transaksi
                connect.close                #tutup koneksi

                st.header('DATA TELAH DISIMPAN')
                st.balloons()