from distutils.log import error
from distutils.util import execute
from tkinter import Button
import streamlit as st
import mysql.connector
import st_db_gudang_koneksi



def tambah():
    st.info('TAMBAH DATA BARANG') #untuk tulis tambah barang
    kode_barang = st.text_input('KODE BARANG')  #untuk input kode barang
    nama_barang = st.text_input('NAMA BARANG')  #untuk input nama barang
    satuan = st.selectbox('SATUAN',['PCS','KG','DUS'])
    stok = st.number_input('STOK BARANG')
    #tombol
    cek = st.button('SAVE')
    if(cek):
        if(kode_barang==''):
            st.error('KODE BARANG BELUM DI INPUT')
        else:
            #buka koneksi
            connect = st_db_gudang_koneksi.koneksi()
            sql = "select * from barang1 where kode_barang = '%s'" % kode_barang
            mycursor = connect.cursor() #siapkan data
            mycursor.execute(sql) #jalankan sql
            dataku = mycursor.fetchall()  #ambil data

            ada = len(dataku)           #ambil banyak data
            if(ada >0):
                st.error('KODE BARANG DOUBLE')
            else:
                #save data
                sql = 'insert into barang1 \
                    (kode_barang,nama_barang,satuan,stok)\
                    value (%s, %s, %s, %s)'
                dt = (kode_barang, nama_barang, satuan, stok)
                mycursor = connect.cursor()
                mycursor.execute(sql, dt)   #jalankan sql
                connect.commit()              #save transaksi
                connect.close                #tutup koneksi

                st.header('DATA TELAH DISIMPAN')
                st.balloons()