
#DB MYSQL
import streamlit as st
import mysql.connector   #fungsi konektor mysql  
import st_db_gudang_koneksi #file koneksi db


def hapus():
    #buka koneksi server
    connect = st_db_gudang_koneksi.koneksi()

    st.info('HAPUS DATA')
    kode_barang = st.text_input('INPUT KODE BARANG MAU HAPUS')

    #tombol
    cek=st.button('DELETE DATA')
    if(cek):

        #cek kode sudah diinput
        if(kode_barang == ''):
            st.error('KODE BARANG BELUM DI INPUT')

        else:
            #cek apakah kode apa
            sql="select * from barang1 where kode_barang = '%s'" % kode_barang
            mycursor = connect.cursor()
            mycursor.execute(sql)       #jalankan sql
            dataku = mycursor.fetchall()    #ambil data

            #cek data,jika NOL = kode salah
            ada = (len(dataku))
            if (ada == 0):
                st.header('KODE SALAH')
            else:
                #sql hapus data
                #pakai parameter = %s (harus huruf %s)
                sql = "DELETE FROM barang1 WHERE kode_barang = '%s'" % kode_barang
                mycursor = connect.cursor()     #buka koneksi
                mycursor.execute(sql) #jalankan sql hapus
                connect.commit()   #save transaksi
                connect.close()    #tutup koneksi DB


                st.header ('Data telah di hapus')
                st.snow()