
#DB MYSQL
import streamlit as st
import mysql.connector   #fungsi konektor mysql  
import st_db_gudang_koneksi #file koneksi db


def hapus_stok():
    #buka koneksi server
    conn = st_db_gudang_koneksi.koneksi()

    st.info('HAPUS STOK')
    stok = st.text_input('INPUT STOK MAU DIHAPUS')

    #tombol
    cek=st.button('DELETE DATA')
    if(cek):

        #cek kode sudah diinput
        if(stok == ''):
            st.error('STOK BELUM DI INPUT')

        else:
            #cek apakah kode apa
            sql="select * from barang where stok = '%s'" % stok
            mycursor = conn.cursor()
            mycursor.execute(sql)       #jalankan sql
            dataku = mycursor.fetchall()    #ambil data

            #cek data,jika NOL = STOK salah
            ada = (len(dataku))
            if (ada == 0):
                st.header('STOK SALAH')
            else:
                #sql hapus data
                #pakai parameter = %s (harus huruf %s)
                sql = "DELETE FROM barang WHERE stok = '%s'" % stok
                mycursor = conn.cursor()     #buka koneksi
                mycursor.execute(sql) #jalankan sql hapus
                conn.commit()   #save transaksi
                conn.close()    #tutup koneksi DB


                st.header ('Data telah di hapus')
                st.snow()