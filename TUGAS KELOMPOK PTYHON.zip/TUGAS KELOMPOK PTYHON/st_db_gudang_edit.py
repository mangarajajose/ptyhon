#DB MYSQL
import streamlit as st
import mysql.connector   #fungsi konektor mysql  
import st_db_gudang_koneksi #file koneksi db



def edit():

    #buka koneksi server
    conn = st_db_gudang_koneksi.koneksi()


    st.info('EDIT DATA BARANG')
    kode = st.text_input('INPUT KODE BARANG EDIT')
    nama = st.text_input('NAMA BARANG')
    satuan = st.selectbox('SATUAN',['PCS','KG','DUS'])
    stok = st.number_input('STOK BARANG')
    #tombol
    cek = st.button('UPDATE DATA')
    if(cek):
        #cek kode sudah diinput
        if(kode==''):
            st.error('KODE BARANG BELUM DI INPUT')
        else:
            #cek apakah kode ada
            sql = "select * from barang where kode_barang = '%s'" % kode
            mycursor = conn.cursor()      #siapkan data
            mycursor.execute(sql)         #jalankan sql
            dataku = mycursor.fetchall()  #ambil data

            ada = (len(dataku))           #ambil banyak data
            if(ada == 0):
                st.header('KODE BARANG SALAH')
            else:
                #SQL UPDATE, pakai parameter = %s (harus huruf %s)
                sql = "update barang set \
                      nama_barang = %s \
                      ,stok = %s \
                      ,satuan = %s \
                       where kode_barang = %s"
                
                dt = (nama, stok ,satuan, kode)

                mycursor = conn.cursor()
                mycursor.execute(sql, dt)   #jalankan sql
                conn.commit()              #save transaksi
                conn.close                #tutup koneksi

                st.header('Data Telah Di Update')
                st.snow()