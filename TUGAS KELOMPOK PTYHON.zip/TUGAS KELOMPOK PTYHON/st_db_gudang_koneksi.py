import streamlit as st
import mysql.connector

def koneksi():
    connect=mysql.connector.connect(
        host = 'localhost'
        ,user = 'root'
        ,password = ''
        ,db       ='gudang'
        ,port = 3306
    
    )
    return connect

if __name__=='__main__':
    koneksi()

    