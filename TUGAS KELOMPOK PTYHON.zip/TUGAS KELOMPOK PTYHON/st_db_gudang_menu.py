import streamlit as st
import st_db_gudang_lihat
import st_db_gudang_hapus
import st_db_gudang_edit
import st_db_gudang_tambah
import st_db_gudang_tambah_stok
import st_db_gudang_hapus_stok
import st_db_gudang_lihat_stok
import st_db_gudang_pdf

def menu_home():
    st.header('Data Barang dengan streamlit')

def menu_programmer():
    st.info('PROGRAMMER')
    st.subheader('Type A')


def menu():
    with st.sidebar:
        pilih=st.selectbox( \
            'Menu Barang',['Home','Programmer','Input Barang' \
                ,'Edit Barang','Delete Barang','----------------TRANSAKSI---------------','Input Stok Masuk','Delete Stok Masuk','--------------LAPORAN-------------','Lihat Stok Barang'\
                ,'Lihat Stok masuk','Print stok barang PDF'])

    if(pilih=='Home'):
        menu_home()
    elif(pilih=='Programmer'):
        menu_programmer()
    elif(pilih=='Input Barang'):
        st_db_gudang_tambah.tambah() 
    elif(pilih=='Edit Barang'):
        st_db_gudang_edit.edit() 
    elif(pilih=='Delete Barang'):
        st_db_gudang_hapus.hapus()
    elif(pilih=='Input Stok Masuk'):
        st_db_gudang_tambah_stok.tambah_stok() 
    elif(pilih=='Delete Stok Masuk'):
        st_db_gudang_hapus_stok.hapus_stok() 
    elif(pilih=='Lihat Stok Barang'):
        st_db_gudang_lihat.lihat() 
    elif(pilih=='Lihat Stok Masuk'):
        st_db_gudang_lihat_stok.lihat_stok() 
    else:
        st_db_gudang_pdf.print_pdf() 
        

def main():
    menu()


if __name__== '__main__':
    main()