import streamlit as st
import mysql.connector
import st_db_gudang_koneksi



def tambah():
    st.info('TAMBAH DATA BARANG') #untuk tulis tambah barang
    kode = st.text_input('KODE BARANG')  #untuk input kode barang
    nama = st.text_input('NAMA BARANG')  #untuk input nama barang
    satuan = st.selectbox('SATUAN',['PCS','KG','DUS'])
    stok = st.number_input('STOK BARANG')
    #tombol
    cek = st.button('SAVE')
    if(cek):
        if(kode==''):
            st.error('KODE BARANG BELUM DI INPUT')
        else:
            #buka koneksi
            conn = st_db_gudang_koneksi.koneksi()
            sql = "select * from barang where kode_barang = '%s'" % kode
            mycursor = conn.cursor() #siapkan data
            mycursor.execute(sql) #jalankan sql
            dataku = mycursor.fetchall()  #ambil data

            ada = len(dataku)           #ambil banyak data
            if(ada >0):
                st.error('KODE BARANG DOUBLE')
            else:
                #save data
                sql = 'insert into barang \
                    (kode_barang,nama_barang,satuan,stok)\
                    value (%s, %s, %s, %s)'
                dt = (kode, nama, satuan, stok)
                mycursor = conn.cursor()
                mycursor.execute(sql, dt)   #jalankan sql
                conn.commit()              #save transaksi
                conn.close                #tutup koneksi

                st.header('DATA TELAH DISIMPAN')
                st.balloons()