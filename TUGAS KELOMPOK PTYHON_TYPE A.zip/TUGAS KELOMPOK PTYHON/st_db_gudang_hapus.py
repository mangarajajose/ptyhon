
#DB MYSQL
import streamlit as st
import mysql.connector   #fungsi konektor mysql  
import st_db_gudang_koneksi #file koneksi db


def hapus():
    #buka koneksi server
    conn = st_db_gudang_koneksi.koneksi()

    st.info('HAPUS DATA')
    kode = st.text_input('INPUT KODE BARANG MAU HAPUS')

    #tombol
    cek=st.button('DELETE DATA')
    if(cek):

        #cek kode sudah diinput
        if(kode == ''):
            st.error('KODE BARANG BELUM DI INPUT')

        else:
            #cek apakah kode apa
            sql="select * from barang where kode_barang = '%s'" % kode
            mycursor = conn.cursor()
            mycursor.execute(sql)       #jalankan sql
            dataku = mycursor.fetchall()    #ambil data

            #cek data,jika NOL = kode salah
            ada = (len(dataku))
            if (ada == 0):
                st.header('KODE SALAH')
            else:
                #sql hapus data
                #pakai parameter = %s (harus huruf %s)
                sql = "DELETE FROM barang WHERE kode_barang = '%s'" % kode
                mycursor = conn.cursor()     #buka koneksi
                mycursor.execute(sql) #jalankan sql hapus
                conn.commit()   #save transaksi
                conn.close()    #tutup koneksi DB


                st.header ('Data telah di hapus')
                st.snow()