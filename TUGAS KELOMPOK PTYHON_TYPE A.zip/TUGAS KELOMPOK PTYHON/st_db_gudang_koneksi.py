import streamlit as streamlit
import mysql.connector

def koneksi():
    conn=mysql.connector.connect(
        host = 'localhost'
        ,user = 'root'
        ,password = ''
        ,db       ='gudang'
        ,port = 3306
    
    )
    return conn

if __name__=='__main__':
    koneksi()

    