#DB MYSQL
import streamlit as st
import mysql.connector   #fungsi konektor mysql  
import st_db_gudang_koneksi #file koneksi db
from fpdf import FPDF #fungsi PDF



def print_pdf():
    st.info('PRINT DATA BARANG KE PDF')
    cek = st.button('Print PDF')
    if (cek):

        #PDF
        #LAYOUT ('P','L'), UNIT('mm','cm','in')
        #FORMAT ('A3','A4' default,'A5','Letter','Legal','(100,150) custom)
        pdf = FPDF('P','cm','A4')
        pdf.set_auto_page_break(auto=True, margin=1)
        pdf.add_page()



        #warna
        #0,0,0        =hitam,220,50,50 = merah, 245,250,50 = kuning
        #90,50,250    =biru,60,240,110 =hijau


        #judul laporan
        pdf.set_font('helvetica','B',20)
        pdf.set_text_color(90,50,250) #biru
        pdf.cell(0,1,'LAPORAN DATA BARANG',align='C')
        pdf.ln()
        pdf.set_text_color(0,0,0) #hitam
        pdf.set_font('helvetica','',10)
        pdf.cell(0,2,'No KODE NAMA BARANG SATUAN STOK ')
        pdf.ln()



        #ambil koneksi server
        conn= st_db_gudang_koneksi.koneksi()
        mycursor = conn.cursor()
        mycursor.execute('select * from barang order by kode_barang')
        dataku = mycursor.fetchall()


        nomer = 0
        tstok = 0

        for dt in dataku:
            nomer = nomer + 1
            xkd   = dt[0]
            xnm   = dt[1]
            xsatuan = dt[2]
            xstok  = dt[3]

            tstok = tstok + xstok


            #print PDF
            pdf.cell(0,0.7,f'({nomer}). {xkd} , {xnm} ,{xsatuan},{xstok}')
            pdf.ln()

        #PRINT TOTAL
        pdf.set_text_color(220,50,50)  #merah
        pdf.cell(0,0.7, f'Total stok = {tstok}')
        conn.close()     #tutup koneksi
        st.balloons()
        #SAVE PDF
        pdf.output('laporan_data_barang.pdf')
        st.warning('OK, sudah print PDF, silahkan download di directori D')

