import streamlit as st
import mysql.connector
import st_db_gudang_koneksi



def tambah_stok():
    st.info('TAMBAH DATA STOK MASUK')
    stok = st.text_input('STOK')  
    #tombol
    cek = st.button('SAVE')
    if(cek):
        if(stok==''):
            st.error('STOK BARANG BELUM DI INPUT')
        else:
            #buka koneksi
            conn = st_db_gudang_koneksi.koneksi()
            sql = "select * from barang where stok= '%s'" % stok
            mycursor = conn.cursor() #siapkan data
            mycursor.execute(sql) #jalankan sql
            dataku = mycursor.fetchall()  #ambil data

            ada = len(dataku)           #ambil banyak data
            if(ada==0):
                st.error('stok tidak kosong')
            else:
                #save data
                sql = 'insert into barang \
                    (stok)\
                    value (%s)'
                dt = (stok)
                mycursor = conn.cursor()
                mycursor.execute(sql, dt)   #jalankan sql
                conn.commit()              #save transaksi
                conn.close                #tutup koneksi

                st.header('DATA TELAH DISIMPAN')
                st.balloons()