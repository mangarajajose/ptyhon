 <?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = Array(
    'smtp_crypto'  => 'tls',
    'protocol'  => 'smtp',
    'smtp_host'   => 'smtp.office365.com',
    'smtp_user'=> 'dmia.system.a2d@ap.denso.com',
    'smtp_pass'=> '@1nD@5mO',
    'smtp_port' => '587',   
    'charset' => 'utf-8',
    'newline' =>"\r\n",
    'crlf' => "\r\n",
    'mailtype' => 'html'            
    ); 